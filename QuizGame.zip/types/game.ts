export type GamePhase =
  | 'lobby'
  | 'countdown'
  | 'question'
  | 'round-result'
  | 'final-result';

export type GameDifficulty = 'any' | 'easy' | 'medium' | 'hard';
export type GameTeamMode = 'ffa' | 'teams';
export type TeamId = 'A' | 'B';

export interface GameSettings {
  rounds: number;
  difficulty: GameDifficulty;
  categoryId: number | null;
  categoryLabel: string;
  powerRoundsEnabled: boolean;
  teamMode: GameTeamMode;
}

export interface PlayerMatchStatsInternal {
  correctAnswers: number;
  answeredQuestions: number;
  fastestAnswerMs: number | null;
  totalAnswerMs: number;
  longestStreak: number;
  currentStreak: number;
}

export interface PlayerMatchStats {
  correctAnswers: number;
  answeredQuestions: number;
  fastestAnswerMs: number | null;
  averageAnswerMs: number | null;
  longestStreak: number;
}

export interface Player {
  id: string;
  nickname: string;
  avatar: string;   // single emoji character
  score: number;
  answeredIndex: number | null; // null = not yet answered this round
  isHost: boolean;
  isReady: boolean;
  teamId: TeamId | null;
}

export interface RoomReaction {
  id: string;
  playerId: string;
  nickname: string;
  avatar: string;
  emoji: string;
  createdAt: number;
}

export interface Question {
  category: string;
  question: string;
  correctIndex: number; // only present in server state; stripped from client during 'question' phase
  answers: string[];    // shuffled: correct + 3 incorrect
}

/** Version of Question sent to clients during the active round — no correct answer */
export interface ClientQuestion {
  category: string;
  question: string;
  answers: string[];
  /** populated only when phase === 'round-result' */
  correctIndex?: number;
}

export interface GameRoom {
  code: string;
  phase: GamePhase;
  hostId: string;
  players: Record<string, Player>;
  playerStats: Record<string, PlayerMatchStatsInternal>;
  questions: Question[];
  currentQuestionIndex: number;
  roundStartedAt: number; // epoch ms — used to compute time bonus
  maxPlayers: number;
  totalRounds: number;
  settings: GameSettings;
  rematchVotes: string[];
  reactions: RoomReaction[];
  powerRoundIndexes: number[];
}

// ─── WebSocket message types ──────────────────────────────────────────────────

export type ClientMessage =
  | { type: 'join'; nickname: string; avatar: string }
  | { type: 'start'; settings?: Partial<GameSettings> }
  | { type: 'answer'; answerIndex: number }
  | { type: 'vote-rematch'; nickname: string }
  | { type: 'start-rematch'; nickname: string }
  | { type: 'toggle-ready'; nickname: string }
  | { type: 'kick-player'; playerId: string }
  | { type: 'send-reaction'; nickname: string; emoji: string };

export type ServerMessage =
  | { type: 'state-update'; room: PublicGameRoom }
  | { type: 'error'; message: string };

/** Room state safe to broadcast to all clients (strips correctIndex during 'question' phase) */
export interface PublicGameRoom {
  code: string;
  phase: GamePhase;
  hostId: string;
  players: Record<string, Player>;
  playerStats: Record<string, PlayerMatchStats>;
  currentQuestion: ClientQuestion | null;
  currentQuestionIndex: number;
  totalRounds: number;
  roundStartedAt: number;
  maxPlayers: number;
  settings: GameSettings;
  rematchVotes: string[];
  reactions: RoomReaction[];
  powerRoundIndexes: number[];
}

// ─── Scoring ──────────────────────────────────────────────────────────────────
export const ROUND_DURATION_MS = 10_000;
export const BASE_POINTS = 100;
export const TIME_BONUS_PER_SECOND = 10;
export const MAX_PLAYERS = 10;
export const TOTAL_ROUNDS = 10;
