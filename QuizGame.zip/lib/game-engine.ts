import {
  ClientQuestion,
  GameRoom,
  GameSettings,
  MAX_PLAYERS,
  Player,
  PlayerMatchStats,
  PlayerMatchStatsInternal,
  PublicGameRoom,
  Question,
  ROUND_DURATION_MS,
  RoomReaction,
  TOTAL_ROUNDS,
} from '@/types/game';
import { calculateScore } from '@/lib/scoring';
import { DEFAULT_CATEGORY, DEFAULT_DIFFICULTY } from '@/lib/game-options';
import { buildPowerRoundIndexes, isPowerRound } from '@/lib/power-rounds';
import { assignPlayersToTeams } from '@/lib/team-mode';

// ─── Pure state-machine functions ────────────────────────────────────────────
// Each function takes the current state and returns a new state object.
// No side effects. Easily unit-testable.

function createDefaultSettings(): GameSettings {
  return {
    rounds: TOTAL_ROUNDS,
    difficulty: DEFAULT_DIFFICULTY,
    categoryId: DEFAULT_CATEGORY.id,
    categoryLabel: DEFAULT_CATEGORY.label,
    powerRoundsEnabled: true,
    teamMode: 'ffa',
  };
}

function createEmptyPlayerStats(): PlayerMatchStatsInternal {
  return {
    correctAnswers: 0,
    answeredQuestions: 0,
    fastestAnswerMs: null,
    totalAnswerMs: 0,
    longestStreak: 0,
    currentStreak: 0,
  };
}

function buildPlayerStats(players: Record<string, Player>): Record<string, PlayerMatchStatsInternal> {
  const playerStats: Record<string, PlayerMatchStatsInternal> = {};
  for (const id of Object.keys(players)) {
    playerStats[id] = createEmptyPlayerStats();
  }
  return playerStats;
}

function toPublicPlayerStats(stats: PlayerMatchStatsInternal): PlayerMatchStats {
  return {
    correctAnswers: stats.correctAnswers,
    answeredQuestions: stats.answeredQuestions,
    fastestAnswerMs: stats.fastestAnswerMs,
    averageAnswerMs:
      stats.answeredQuestions > 0
        ? Math.round(stats.totalAnswerMs / stats.answeredQuestions)
        : null,
    longestStreak: stats.longestStreak,
  };
}

function pruneReactions(reactions: RoomReaction[], now = Date.now()): RoomReaction[] {
  return reactions
    .filter((reaction) => now - reaction.createdAt <= 5000)
    .slice(-8);
}

export function createRoom(code: string, hostId: string, hostname: string, avatar = '⚡'): GameRoom {
  const host: Player = {
    id: hostId,
    nickname: hostname,
    avatar,
    score: 0,
    answeredIndex: null,
    isHost: true,
    isReady: true,
    teamId: null,
  };
  return {
    code,
    phase: 'lobby',
    hostId,
    players: { [hostId]: host },
    playerStats: { [hostId]: createEmptyPlayerStats() },
    questions: [],
    currentQuestionIndex: 0,
    roundStartedAt: 0,
    maxPlayers: MAX_PLAYERS,
    totalRounds: TOTAL_ROUNDS,
    settings: createDefaultSettings(),
    rematchVotes: [],
    reactions: [],
    powerRoundIndexes: buildPowerRoundIndexes(TOTAL_ROUNDS, true),
  };
}

export function joinRoom(room: GameRoom, playerId: string, nickname: string, avatar = '⚡'): GameRoom {
  if (room.phase !== 'lobby') {
    throw new Error('Game already in progress');
  }
  if (Object.keys(room.players).length >= room.maxPlayers) {
    throw new Error('Room is full');
  }
  const trimmed = nickname.trim().slice(0, 20);
  if (!trimmed) throw new Error('Nickname required');

  const player: Player = {
    id: playerId,
    nickname: trimmed,
    avatar,
    score: 0,
    answeredIndex: null,
    isHost: false,
    isReady: false,
    teamId: null,
  };
  return {
    ...room,
    players: { ...room.players, [playerId]: player },
    playerStats: { ...room.playerStats, [playerId]: createEmptyPlayerStats() },
  };
}

export function removePlayer(room: GameRoom, playerId: string): GameRoom {
  const { [playerId]: _removed, ...rest } = room.players;
  const { [playerId]: _removedStats, ...restStats } = room.playerStats;
  let newHostId = room.hostId;
  let newPlayers = { ...rest };
  if (room.hostId === playerId) {
    const ids = Object.keys(newPlayers);
    if (ids.length > 0) {
      newHostId = ids[0];
      newPlayers = {
        ...newPlayers,
        [newHostId]: { ...newPlayers[newHostId], isHost: true },
      };
    }
  }

  const removedNickname = room.players[playerId]?.nickname;
  return {
    ...room,
    players: newPlayers,
    playerStats: restStats,
    hostId: newHostId,
    rematchVotes: removedNickname
      ? room.rematchVotes.filter((nickname) => nickname !== removedNickname)
      : room.rematchVotes,
    reactions: room.reactions.filter((reaction) => reaction.playerId !== playerId),
  };
}

export function startGame(room: GameRoom, questions: Question[], settings?: Partial<GameSettings>): GameRoom {
  if (room.phase !== 'lobby' && room.phase !== 'final-result') {
    throw new Error('Game already started');
  }
  const resetPlayers: Record<string, Player> = {};
  for (const [id, p] of Object.entries(room.players)) {
    resetPlayers[id] = { ...p, score: 0, answeredIndex: null, isReady: false };
  }

  const nextSettings: GameSettings = {
    ...room.settings,
    ...settings,
    rounds: questions.length,
    categoryLabel: settings?.categoryLabel ?? room.settings.categoryLabel,
    powerRoundsEnabled: settings?.powerRoundsEnabled ?? room.settings.powerRoundsEnabled,
    teamMode: settings?.teamMode ?? room.settings.teamMode,
  };

  const assignedPlayers = assignPlayersToTeams(resetPlayers, nextSettings.teamMode);

  return {
    ...room,
    phase: 'countdown',
    questions,
    currentQuestionIndex: 0,
    roundStartedAt: 0,
    players: assignedPlayers,
    playerStats: buildPlayerStats(assignedPlayers),
    totalRounds: questions.length,
    settings: nextSettings,
    rematchVotes: [],
    reactions: [],
    powerRoundIndexes: buildPowerRoundIndexes(questions.length, nextSettings.powerRoundsEnabled),
  };
}

export function beginRound(room: GameRoom): GameRoom {
  const resetPlayers: Record<string, Player> = {};
  for (const [id, p] of Object.entries(room.players)) {
    resetPlayers[id] = { ...p, answeredIndex: null };
  }
  return {
    ...room,
    phase: 'question',
    players: resetPlayers,
    roundStartedAt: Date.now(),
    rematchVotes: [],
    reactions: [],
  };
}

export function submitAnswer(
  room: GameRoom,
  playerId: string,
  answerIndex: number
): GameRoom {
  if (room.phase !== 'question') return room;
  const player = room.players[playerId];
  if (!player) return room;
  if (player.answeredIndex !== null) return room;

  const question = room.questions[room.currentQuestionIndex];
  const isCorrect = answerIndex === question.correctIndex;
  const elapsedMs = Math.max(0, Math.min(ROUND_DURATION_MS, Date.now() - room.roundStartedAt));
  const powerRound = isPowerRound(room.powerRoundIndexes, room.currentQuestionIndex);
  const secondsRemaining = Math.max(
    0,
    Math.floor((ROUND_DURATION_MS - elapsedMs) / 1000)
  );
  const points = isCorrect ? calculateScore(secondsRemaining, powerRound ? 2 : 1) : 0;
  const prevStats = room.playerStats[playerId] ?? createEmptyPlayerStats();

  const updatedPlayer: Player = {
    ...player,
    answeredIndex: answerIndex,
    score: player.score + points,
  };

  const nextStreak = isCorrect ? prevStats.currentStreak + 1 : 0;
  const updatedStats: PlayerMatchStatsInternal = {
    ...prevStats,
    correctAnswers: prevStats.correctAnswers + (isCorrect ? 1 : 0),
    answeredQuestions: prevStats.answeredQuestions + 1,
    fastestAnswerMs:
      prevStats.fastestAnswerMs === null
        ? elapsedMs
        : Math.min(prevStats.fastestAnswerMs, elapsedMs),
    totalAnswerMs: prevStats.totalAnswerMs + elapsedMs,
    currentStreak: nextStreak,
    longestStreak: Math.max(prevStats.longestStreak, nextStreak),
  };

  return {
    ...room,
    players: { ...room.players, [playerId]: updatedPlayer },
    playerStats: { ...room.playerStats, [playerId]: updatedStats },
  };
}

export function revealRound(room: GameRoom): GameRoom {
  const updatedStats = { ...room.playerStats };
  for (const [id, player] of Object.entries(room.players)) {
    if (player.answeredIndex === null && updatedStats[id]) {
      updatedStats[id] = {
        ...updatedStats[id],
        currentStreak: 0,
      };
    }
  }

  return { ...room, phase: 'round-result', playerStats: updatedStats };
}

export function advanceRound(room: GameRoom): GameRoom {
  const next = room.currentQuestionIndex + 1;
  if (next >= room.totalRounds) {
    return { ...room, phase: 'final-result', reactions: [] };
  }
  return { ...room, phase: 'countdown', currentQuestionIndex: next, reactions: [] };
}

export function toggleReady(room: GameRoom, playerId: string): GameRoom {
  if (room.phase !== 'lobby') return room;
  const player = room.players[playerId];
  if (!player) return room;
  return {
    ...room,
    players: {
      ...room.players,
      [playerId]: { ...player, isReady: !player.isReady },
    },
  };
}

export function allPlayersReady(room: GameRoom): boolean {
  const players = Object.values(room.players);
  return players.length > 1 && players.every((player) => player.isReady);
}

export function addReaction(room: GameRoom, playerId: string, emoji: string): GameRoom {
  if (room.phase === 'lobby') return room;
  const player = room.players[playerId];
  if (!player) return room;

  const trimmedEmoji = emoji.trim().slice(0, 2);
  if (!trimmedEmoji) return room;

  const now = Date.now();
  const recentReactions = pruneReactions(room.reactions, now).filter((reaction) => {
    return !(reaction.playerId === playerId && now - reaction.createdAt < 1200);
  });

  const reaction: RoomReaction = {
    id: `${playerId}:${now}`,
    playerId,
    nickname: player.nickname,
    avatar: player.avatar,
    emoji: trimmedEmoji,
    createdAt: now,
  };

  return {
    ...room,
    reactions: [...recentReactions, reaction].slice(-8),
  };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

export function toPublicRoom(room: GameRoom): PublicGameRoom {
  const q = room.questions[room.currentQuestionIndex] ?? null;
  let currentQuestion: ClientQuestion | null = null;
  if (q) {
    currentQuestion = {
      category: q.category,
      question: q.question,
      answers: q.answers,
      correctIndex:
        room.phase === 'round-result' || room.phase === 'final-result'
          ? q.correctIndex
          : undefined,
    };
  }
  return {
    code: room.code,
    phase: room.phase,
    hostId: room.hostId,
    players: room.players,
    playerStats: Object.fromEntries(
      Object.entries(room.playerStats).map(([id, stats]) => [id, toPublicPlayerStats(stats)])
    ),
    currentQuestion,
    currentQuestionIndex: room.currentQuestionIndex,
    totalRounds: room.totalRounds,
    roundStartedAt: room.roundStartedAt,
    maxPlayers: room.maxPlayers,
    settings: room.settings,
    rematchVotes: room.rematchVotes,
    reactions: pruneReactions(room.reactions),
    powerRoundIndexes: room.powerRoundIndexes,
  };
}

export function allAnswered(room: GameRoom): boolean {
  return Object.values(room.players).every((p) => p.answeredIndex !== null);
}

export function rejoinGame(room: GameRoom, newSocketId: string, nickname: string): GameRoom {
  const normalized = nickname.trim().slice(0, 20);
  const entry = Object.entries(room.players).find(
    ([, p]) => p.nickname === normalized
  );
  if (!entry) throw new Error('Player not found in this game');

  const [oldId, player] = entry;
  const { [oldId]: _removed, ...rest } = room.players;
  const { [oldId]: oldStats, ...restStats } = room.playerStats;
  const updatedPlayer: Player = { ...player, id: newSocketId };
  const newHostId = room.hostId === oldId ? newSocketId : room.hostId;

  return {
    ...room,
    players: { ...rest, [newSocketId]: updatedPlayer },
    playerStats: { ...restStats, [newSocketId]: oldStats ?? createEmptyPlayerStats() },
    hostId: newHostId,
    reactions: room.reactions.map((reaction) =>
      reaction.playerId === oldId
        ? { ...reaction, playerId: newSocketId, nickname: normalized, avatar: updatedPlayer.avatar }
        : reaction
    ),
  };
}

export function voteRematch(room: GameRoom, nickname: string): GameRoom {
  if (room.phase !== 'final-result') return room;
  const normalized = nickname.trim().slice(0, 20);
  if (!normalized || room.rematchVotes.includes(normalized)) return room;
  return {
    ...room,
    rematchVotes: [...room.rematchVotes, normalized],
  };
}
