import { GameDifficulty } from '@/types/game';

export interface CategoryOption {
  id: number | null;
  label: string;
}

export interface DifficultyOption {
  value: GameDifficulty;
  label: string;
}

export const CATEGORY_OPTIONS: CategoryOption[] = [
  { id: null, label: 'Any Category' },
  { id: 9, label: 'General Knowledge' },
  { id: 11, label: 'Film' },
  { id: 12, label: 'Music' },
  { id: 17, label: 'Science' },
  { id: 18, label: 'Computers' },
  { id: 21, label: 'Sports' },
  { id: 22, label: 'Geography' },
  { id: 23, label: 'History' },
];

export const DEFAULT_CATEGORY = CATEGORY_OPTIONS[0];

export const DIFFICULTY_OPTIONS: DifficultyOption[] = [
  { value: 'any', label: 'Any Difficulty' },
  { value: 'easy', label: 'Easy' },
  { value: 'medium', label: 'Medium' },
  { value: 'hard', label: 'Hard' },
];

export const DEFAULT_DIFFICULTY = DIFFICULTY_OPTIONS[0].value;

export function getCategoryLabel(categoryId: number | null): string {
  return CATEGORY_OPTIONS.find((option) => option.id === categoryId)?.label ?? DEFAULT_CATEGORY.label;
}

export function getDifficultyLabel(difficulty: GameDifficulty): string {
  return DIFFICULTY_OPTIONS.find((option) => option.value === difficulty)?.label ?? DIFFICULTY_OPTIONS[0].label;
}