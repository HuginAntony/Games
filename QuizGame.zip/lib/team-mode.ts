import { GameTeamMode, Player, TeamId } from '@/types/game';

export interface TeamStanding {
  teamId: TeamId;
  label: string;
  score: number;
  playerCount: number;
}

const TEAM_IDS: TeamId[] = ['A', 'B'];

export function getTeamLabel(teamId: TeamId | null): string {
  return teamId ? `Team ${teamId}` : 'Free For All';
}

export function assignPlayersToTeams(
  players: Record<string, Player>,
  teamMode: GameTeamMode
): Record<string, Player> {
  if (teamMode === 'ffa') {
    return Object.fromEntries(
      Object.entries(players).map(([id, player]) => [id, { ...player, teamId: null }])
    );
  }

  let index = 0;
  return Object.fromEntries(
    Object.entries(players).map(([id, player]) => {
      const teamId = TEAM_IDS[index % TEAM_IDS.length];
      index += 1;
      return [id, { ...player, teamId }];
    })
  );
}

export function getTeamStandings(players: Record<string, Player>): TeamStanding[] {
  const totals = new Map<TeamId, TeamStanding>();

  for (const player of Object.values(players)) {
    if (!player.teamId) continue;
    const existing = totals.get(player.teamId) ?? {
      teamId: player.teamId,
      label: getTeamLabel(player.teamId),
      score: 0,
      playerCount: 0,
    };
    existing.score += player.score;
    existing.playerCount += 1;
    totals.set(player.teamId, existing);
  }

  return Array.from(totals.values()).sort((a, b) => b.score - a.score || a.teamId.localeCompare(b.teamId));
}