export function buildPowerRoundIndexes(totalRounds: number, enabled: boolean): number[] {
  if (!enabled || totalRounds <= 0) return [];
  return [Math.floor((totalRounds - 1) / 2)];
}

export function isPowerRound(powerRoundIndexes: number[], roundIndex: number): boolean {
  return powerRoundIndexes.includes(roundIndex);
}