"use client";

import { Suspense } from "react";
import { useParams, useSearchParams, useRouter } from "next/navigation";
import { usePartySocket } from "@/hooks/usePartySocket";
import { TrophyBanner } from "@/components/TrophyBanner/TrophyBanner";
import { Podium } from "@/components/Podium/Podium";
import { NeonButton } from "@/components/NeonButton/NeonButton";
import { getDifficultyLabel } from "@/lib/game-options";
import { getTeamStandings } from "@/lib/team-mode";
import { Player, PublicGameRoom } from "@/types/game";
import styles from "./page.module.css";

function formatMs(ms: number | null): string {
  if (ms === null) return "—";
  return `${(ms / 1000).toFixed(2)}s`;
}

function getAccuracy(correctAnswers: number, totalRounds: number): number {
  if (totalRounds === 0) return 0;
  return Math.round((correctAnswers / totalRounds) * 100);
}

function ResultsPageInner() {
  const params = useParams<{ code: string }>();
  const searchParams = useSearchParams();
  const router = useRouter();
  const code = params.code;
  const nickname = searchParams.get("name") || "Player";
  const avatar = searchParams.get("avatar") || "⚡";

  const { gameState, send } = usePartySocket(code, (room: PublicGameRoom) => {
    if (room.phase === "countdown" || room.phase === "question") {
      router.push(
        "/game/" + code +
        "?name=" + encodeURIComponent(nickname) +
        "&avatar=" + encodeURIComponent(avatar)
      );
    }
  });

  const players: Player[] = gameState
    ? Object.values(gameState.players).sort((a, b) => b.score - a.score)
    : [];

  const winner = players[0] ?? null;
  const isWinner = winner?.nickname === nickname;
  const myPlayer = players.find((player) => player.nickname === nickname) ?? null;
  const myStats = myPlayer ? gameState?.playerStats[myPlayer.id] ?? null : null;
  const rematchVotes = gameState?.rematchVotes ?? [];
  const hasVotedRematch = rematchVotes.includes(nickname);
  const hostPlayer = players.find((player) => player.isHost) ?? null;
  const isHost = hostPlayer?.nickname === nickname;
  const teamStandings = gameState ? getTeamStandings(gameState.players) : [];
  const winningTeam = teamStandings[0] ?? null;

  return (
    <main className={styles.page}>
      <h1 className={styles.title}>Game Over</h1>

      {gameState && (
        <div className={styles.matchCard}>
          <div className={styles.matchLabel}>Match Settings</div>
          <div className={styles.matchValue}>
            {gameState.settings.categoryLabel} · {getDifficultyLabel(gameState.settings.difficulty)} · {gameState.totalRounds} questions{gameState.settings.powerRoundsEnabled ? ` · Power Round on Q${gameState.powerRoundIndexes[0] + 1}` : ""}{gameState.settings.teamMode === "teams" ? " · Team Mode" : ""}
          </div>
        </div>
      )}

      {gameState?.settings.teamMode === "teams" && winningTeam && (
        <div className={styles.teamPanel}>
          <h2 className={styles.statsTitle}>Winning Team</h2>
          <div className={styles.teamGrid}>
            {teamStandings.map((team) => (
              <div key={team.teamId} className={styles.teamStatCard}>
                <span className={styles.statLabel}>{team.label}</span>
                <span className={styles.statValue}>{team.score.toLocaleString()} pts</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {winner && (
        <TrophyBanner winner={winner} isCurrentPlayer={isWinner} />
      )}

      {players.length > 0 && (
        <Podium players={players.slice(0, 3)} nickname={nickname} />
      )}

      <div className={styles.leaderboard}>
        <h2 className={styles.lbTitle}>Final Scores</h2>
        <ol className={styles.lbList}>
          {players.map((p, idx) => (
            <li
              key={p.id}
              className={styles.lbRow + (p.nickname === nickname ? (" " + styles.me) : "")}
              style={{ animationDelay: (idx * 0.08) + "s" }}
            >
              <span className={styles.lbRank}>
                {idx === 0 ? "🥇" : idx === 1 ? "🥈" : idx === 2 ? "🥉" : "#" + (idx + 1)}
              </span>
              <span className={styles.lbAvatar}>{p.avatar}</span>
              <span className={styles.lbName}>{p.nickname}</span>
              <span className={styles.lbScore}>{p.score.toLocaleString()} pts</span>
            </li>
          ))}
        </ol>
      </div>

      {gameState && myStats && (
        <div className={styles.statsPanel}>
          <h2 className={styles.statsTitle}>Your Match Stats</h2>
          <div className={styles.statsGrid}>
            <div className={styles.statCard}>
              <span className={styles.statLabel}>Accuracy</span>
              <span className={styles.statValue}>{getAccuracy(myStats.correctAnswers, gameState.totalRounds)}%</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statLabel}>Correct Answers</span>
              <span className={styles.statValue}>{myStats.correctAnswers} / {gameState.totalRounds}</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statLabel}>Fastest Answer</span>
              <span className={styles.statValue}>{formatMs(myStats.fastestAnswerMs)}</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statLabel}>Average Speed</span>
              <span className={styles.statValue}>{formatMs(myStats.averageAnswerMs)}</span>
            </div>
            <div className={styles.statCard}>
              <span className={styles.statLabel}>Best Streak</span>
              <span className={styles.statValue}>{myStats.longestStreak}</span>
            </div>
          </div>
        </div>
      )}

      {gameState && (
        <div className={styles.rematchPanel}>
          <div>
            <h2 className={styles.statsTitle}>Rematch</h2>
            <p className={styles.rematchText}>{rematchVotes.length} / {players.length} players ready</p>
          </div>
          <div className={styles.actions}>
            <NeonButton
              variant={hasVotedRematch ? "ghost" : "pink"}
              onClick={() => send({ type: "vote-rematch", nickname })}
              disabled={hasVotedRematch}
            >
              {hasVotedRematch ? "Voted" : "Vote Rematch"}
            </NeonButton>
            {isHost && (
              <NeonButton
                variant="cyan"
                onClick={() => send({ type: "start-rematch", nickname })}
              >
                Start Rematch
              </NeonButton>
            )}
          </div>
        </div>
      )}

      <div className={styles.actions}>
        <NeonButton variant="cyan" onClick={() => router.push("/")}>Play Again</NeonButton>
        <NeonButton variant="ghost" onClick={() => router.push("/")}>Home</NeonButton>
      </div>
    </main>
  );
}


export default function ResultsPage() {
  return (
    <Suspense fallback={<div style={{display:"flex",minHeight:"100vh",alignItems:"center",justifyContent:"center",color:"var(--text-muted)"}}>Loading...</div>}>
      <ResultsPageInner />
    </Suspense>
  );
}
