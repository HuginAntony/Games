import { NextResponse } from 'next/server';
import { fetchQuestionsFromOtdb } from '@/lib/opentdb';
import { GameDifficulty } from '@/types/game';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const amount = Math.min(50, Math.max(1, parseInt(searchParams.get('amount') || '10', 10)));
    const categoryIdRaw = searchParams.get('categoryId');
    const categoryId = categoryIdRaw ? parseInt(categoryIdRaw, 10) : null;
    const difficultyRaw = searchParams.get('difficulty');
    const difficulty: GameDifficulty =
      difficultyRaw === 'easy' || difficultyRaw === 'medium' || difficultyRaw === 'hard'
        ? difficultyRaw
        : 'any';

    const questions = await fetchQuestionsFromOtdb(amount, {
      categoryId: Number.isNaN(categoryId ?? Number.NaN) ? null : categoryId,
      difficulty,
    });
    return NextResponse.json(questions);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.error('Questions API error:', msg);
    const status = msg.includes('rate limit') || msg.includes('code 5') ? 429 : 503;
    return NextResponse.json({ error: msg }, { status });
  }
}
