# QuizBlitz ⚡

QuizBlitz is a fast, real-time party quiz game built with **Next.js 16**, **React 19**, and **PartyKit**. It now supports live multiplayer rooms for up to **10 players**, solo practice, host-controlled round counts, category and difficulty setup, Power Rounds, ready checks, host kick controls, in-match reactions, QR-code joining, rematch flow, server-authoritative scoring, and a polished neon UI with sound and end-of-game celebration.

The current implementation is strong for quick-play sessions and local/demo deployment. The next step is less about basic functionality and more about retention, replayability, social tension, and persistence.

This repository now includes two complete no-database delivery phases plus two shipped Phase 3 slices: setup customization, session match stats, rematch support, session-based social controls, configurable Power Rounds, and live Team Mode. Later phases remain intentionally persistence-light until a database is introduced.

---

## Table of Contents

1. [Current Game Surface](#current-game-surface)
2. [Gameplay Loop](#gameplay-loop)
3. [Architecture](#architecture)
4. [Project Structure](#project-structure)
5. [Data and Persistence](#data-and-persistence)
6. [Getting Started](#getting-started)
7. [Scripts](#scripts)
8. [Testing](#testing)
9. [Deployment](#deployment)
10. [Delivery Phases](#delivery-phases)
11. [Product Roadmap](#product-roadmap)
12. [Database Recommendations](#database-recommendations)
13. [Competitive Ideas](#competitive-ideas)

---

## Current Game Surface

### Implemented Features

| Area | What exists now |
|---|---|
| **Multiplayer rooms** | Up to **10 players** per room over PartyKit WebSockets |
| **Solo mode** | Single-player mode with personal best stored in `localStorage` |
| **Round counts** | Host can start **5 / 10 / 15 / 20** question multiplayer games; solo mode supports the same counts |
| **Match setup** | Solo and host flows now support category and difficulty selection |
| **Power Rounds** | A configurable featured round doubles points for both solo and multiplayer matches |
| **Team Mode** | Multiplayer hosts can switch from free-for-all to **2 teams**, with automatic team assignment, team badges, and team standings during play and on results |
| **Ready checks** | Multiplayer lobbies require at least 2 players and everyone ready before the host can start |
| **Lobby moderation** | The host can remove players from the lobby before the game starts |
| **Question source** | Questions come from **Open Trivia DB** with retry and back-off handling |
| **Real-time clock** | Per-question **10 second** timer is derived from a server broadcast timestamp |
| **Scoring** | Correct answer score = **100 + 10 x seconds remaining**, capped at **200** normally and **400** during a Power Round |
| **Answer safety** | Correct answer is hidden from clients during the active question phase |
| **Reconnect flow** | Lobby-to-game socket changes are handled by re-associating the player by nickname |
| **Join UX** | Players can join via room code or by scanning a **QR code** in the lobby |
| **Avatar system** | Players can choose from a built-in emoji avatar set |
| **Scoreboard UX** | Live scoreboard shows score deltas and answered/thinking indicators |
| **Audio** | Web Audio API sound effects for countdown, answers, new rounds, and game over, with mute persisted in `localStorage` |
| **Match recap** | Results screen shows per-session stats such as accuracy, fastest answer, average speed, and best streak |
| **Social reactions** | Players can fire quick emoji reactions during the match and see them sync live across clients |
| **Rematch** | Results screen supports rematch voting and host-controlled restart without leaving the room |
| **Results** | Final leaderboard, podium, trophy banner, and winner confetti |

### What Feels Good Already

- Fast room creation and low-friction joining.
- Server-authoritative multiplayer loop instead of trusting the browser.
- Strong visual feedback during countdown, reveal, and results.
- Minimal dependency footprint.
- Clean separation between pure game logic and network/runtime code.

### Current Gaps

- No persistent player profiles or cross-session progression.
- No stored game history, analytics, or season leaderboard.
- Question source is fully external and uncached beyond runtime fetches.
- No spectator mode or advanced power-round variants yet.
- No persistent progression, unlocks, or global history yet.

---

## Gameplay Loop

```text
Home
  -> Solo Play
     -> Choose avatar + round count
     -> Fetch questions
     -> Timed question loop
     -> Personal best screen

  -> Create Room
     -> Host enters lobby
     -> Shares room code or QR code
      -> Players join with nickname + avatar
      -> Host selects round count, category, difficulty, Power Round mode, and free-for-all vs team play
      -> Players ready up; host can remove players before start
     -> Countdown
     -> Timed question loop
      -> Live reaction bursts
      -> Optional Power Round for double points
      -> Optional team scoring overlay and team-vs-team standings
     -> Round reveal
      -> Final leaderboard + podium + confetti + stats
      -> Optional rematch

  -> Join Room
     -> Enter room code
     -> Join lobby
     -> Wait for host start
```

### Multiplayer State Machine

```text
lobby -> countdown -> question -> round-result -> countdown -> ... -> final-result
```

---

## Architecture

```text
Browser (Next.js App Router)
  app/page.tsx              Home / create / join / solo entry
  app/lobby/[code]          Lobby, room code, QR join, host controls
  app/game/[code]           Live multiplayer game UI
  app/game/solo             Solo mode
  app/results/[code]        Final leaderboard and podium
  hooks/usePartySocket      WebSocket connection manager
  hooks/useCountdown        Client countdown derived from server timestamp
  hooks/useSound            Web Audio synthesised sound effects
  components/*              Question card, scoreboard, countdown ring, QR, podium, trophy

PartyKit Server
  party/game.ts             Room runtime, connection lifecycle, timers, broadcast
  lib/game-engine.ts        Pure state-machine transitions
  lib/scoring.ts            Score strategy
  lib/opentdb.ts            Shared OpenTDB fetcher for server and API route

Next.js API
  app/api/questions/route.ts
                           Browser-safe question endpoint for solo mode

External Service
  opentdb.com               Trivia content source
```

### Key Design Decisions

- **Pure state machine**: `lib/game-engine.ts` owns the state transitions, which keeps game rules testable and isolated from transport logic.
- **Server-authoritative timing**: the server writes `roundStartedAt`; clients derive countdown from that timestamp so late joiners and reconnects stay aligned.
- **Hidden answers during active rounds**: public room state strips `correctIndex` until reveal/final phases.
- **Reconnect by player identity, not stale socket ID**: the game page resolves the current player by nickname after reconnect, and the room swaps socket IDs when players move from lobby to game.
- **Two fetch paths, one data source**: multiplayer fetches directly from OpenTDB on the PartyKit side; solo mode uses the Next.js API route, which uses the same OpenTDB fetcher.
- **No-database first phase**: replayability improvements are stored in room state and browser storage first, delaying persistence complexity until it adds clear product value.

### Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 16, React 19, TypeScript |
| Real-time transport | PartyKit + PartySocket |
| Styling | CSS Modules + global CSS variables |
| Visual effects | `canvas-confetti`, CSS keyframes, SVG countdown ring |
| QR join | `qrcode.react` |
| Testing | Playwright |

---

## Project Structure

```text
app/
  api/questions/route.ts      Question API for solo mode
  game/[code]/page.tsx        Multiplayer play screen
  game/solo/page.tsx          Solo mode
  lobby/[code]/page.tsx       Lobby and host controls
  results/[code]/page.tsx     Final scoreboard
  page.tsx                    Home screen

components/
  CountdownRing/
  NeonButton/
  Podium/
  QRCode/
  QuestionCard/
  Scoreboard/
  TrophyBanner/

hooks/
  useCountdown.ts
  usePartySocket.ts
  useSound.ts

lib/
  game-engine.ts
  opentdb.ts
  team-mode.ts
  questions.ts
  room-factory.ts
  scoring.ts

party/
  game.ts

tests/
  home.spec.ts
  lobby.spec.ts
  multiplayer.spec.ts
  solo.spec.ts
```

---

## Data and Persistence

### What Is Persisted Today

| Data | Where it lives |
|---|---|
| Active multiplayer room state | In memory inside the PartyKit room |
| Solo personal best | Browser `localStorage` |
| Audio mute preference | Browser `localStorage` |
| Questions | Fetched on demand from OpenTDB |

### What Is Not Persisted Today

- Multiplayer match history
- Global leaderboard data
- Player accounts or cosmetics
- Daily challenges and streaks
- Moderation and abuse audit logs
- Cached question bank

### What Was Added Without a Database

- Match category and difficulty selection
- Per-match stats on the results screen
- Rematch voting and host-controlled restart
- 10-player room cap aligned to the intended product scale
- Ready-up lobby gating with a 2-player minimum
- Host kick controls in the lobby
- In-match emoji reactions synced through room state
- Team assignment and team standings derived entirely from room state

### Current Persistence Assessment

For the current product, **a database is not required** to make the live room gameplay work. PartyKit room memory is enough for ephemeral quiz sessions.

For the next stage of the game, **a database becomes worthwhile** if you want any of the following:

- Saved game history and replays
- Global or seasonal leaderboards
- User accounts, unlocks, XP, cosmetics, ranks, or streaks
- Curated question packs and admin tooling
- Daily challenges or scheduled events
- Analytics on retention, answer speed, or difficulty balance
- Faster and more reliable question delivery through caching and prefetching

---

## Getting Started

### Prerequisites

- Node.js 20+
- npm 10+

### Install

```bash
npm install
```

### Run Locally

Recommended:

```bash
npm run dev
```

This starts:

- Next.js app on `http://localhost:3000`
- PartyKit on `localhost:1999`

Run separately if needed:

```bash
npm run dev:next
npm run dev:party
```

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `NEXT_PUBLIC_PARTYKIT_HOST` | `localhost:1999` | PartyKit host used by the browser client |

---

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Start Next.js and PartyKit together |
| `npm run dev:next` | Start only the Next.js app |
| `npm run dev:party` | Start only the PartyKit server |
| `npm run build` | Create a production Next.js build |
| `npm run start` | Run the production Next.js server |
| `npm run type-check` | Run TypeScript without emitting files |
| `npm test` | Run Playwright tests |
| `npm run test:ui` | Open Playwright UI mode |
| `npm run test:report` | Open the Playwright HTML report |
| `npm run deploy:party` | Deploy PartyKit |

---

## Testing

Tests use **Playwright** with Chromium.

- The test runner auto-starts the **Next.js** dev server.
- **PartyKit must be running separately** for the multiplayer integration suite.

### Current Automated Coverage

| File | Tests | What it covers |
|---|---|---|
| `tests/home.spec.ts` | 7 | Home screen rendering, navigation, validation, and solo setup controls |
| `tests/solo.spec.ts` | 5 | Solo question loading, answer disabling, full run, progress UI, and Power Round banner |
| `tests/lobby.spec.ts` | 6 | Lobby UI behavior when WebSocket is unavailable, including setup controls and Team Mode toggle |
| `tests/multiplayer.spec.ts` | 6 | Ready-gated host/join flow, live lobby sync, host kick, reaction sync, live team assignment, and Team Mode rematch persistence |

Total: **24 Playwright tests**.

### Run Tests

```bash
npm test
```

For multiplayer coverage, start the full app first:

```bash
npm run dev
npm test
```

---

## Deployment

### PartyKit

```bash
npm run deploy:party
```

This deploys `party/game.ts` to PartyKit/Cloudflare.

### Vercel

Deploy the Next.js app to Vercel and set:

```text
NEXT_PUBLIC_PARTYKIT_HOST=your-project.partykit.dev
```

The repository already includes a `vercel.json` mapping for that environment variable.

---

## Delivery Phases

### Phase 1: No-Database Replayability

Implemented in this repository now:

- 10-player room cap
- Category selection
- Difficulty selection
- Results-screen match stats
- Rematch voting
- Host-controlled rematch start

This phase improves repeat play and session quality without introducing durable storage.

### Phase 2: More Session-Based Social Gameplay

Implemented in this repository now:

- Ready-up lobby gating
- Minimum 2 ready players before start
- Host kick controls in the lobby
- In-match emoji reaction sync

This phase improves real room flow, reduces accidental starts, and makes matches feel more social without introducing persistence.

### Phase 3: Gameplay Modifiers And Expanded Session Modes

Implemented in this repository now:

- Configurable Power Round toggle in solo and multiplayer setup
- One featured double-points round per match
- In-match Power Round badge and results summary indicator
- Host-selectable Team Mode for multiplayer rooms
- Automatic Team A / Team B assignment at game start
- Team labels on the live scoreboard plus team standings in-match and on results

This phase begins adding drama and score swings without needing any persistence layer.

Recommended next, still without a database:

- Spectator mode
- Advanced modifier presets such as streak bonus, sudden death, or final surge

### Phase 4: Persistence Layer

Only add once the product needs cross-session value:

- Match history
- Player profiles
- Progression and unlocks
- Curated question cache
- Leaderboards and seasons

---

## Product Roadmap

If the goal is to compete with stronger party trivia products, the biggest gains are not in adding more buttons. The game needs more reasons to come back, more moments that create tension in a room, and more social identity.

### High-Impact Features

| Theme | Why it matters | Feature ideas |
|---|---|---|
| **Replayability** | Keeps sessions from feeling samey | Categories, difficulty ladders, themed packs, daily mixes |
| **Social energy** | Makes the room feel alive | Reactions, roast/cheer moments, rival highlights, rematch voting |
| **Spectacle** | Improves streamability and party feel | Big round intros, comeback alerts, streak effects, sudden-death finals |
| **Progression** | Gives players medium-term goals | XP, levels, titles, badges, unlockable avatars/themes |
| **Competition** | Creates reasons to improve | Ranked playlists, seasons, leagues, personal stats dashboard |
| **UGC / creator mode** | Lets communities own the content | Custom packs, classroom mode, creator playlists, shareable room presets |

### Recommended Feature Order

1. Category and difficulty selection
2. Daily challenge and streak system
3. Stored match history and stats
4. Party-friendly power rounds, team play, and modifiers
5. Custom question packs
6. Seasonal leaderboard and progression

---

## Database Recommendations

### Do You Need a Database Right Now?

No, not for basic room-based multiplayer. The game already works with:

- PartyKit room memory for live sessions
- OpenTDB for question supply
- `localStorage` for solo-only persistence

### When You Should Add One

Add a database once you want persistence beyond a single browser session or a single live room.

### What the Database Should Store First

| Priority | Data |
|---|---|
| 1 | Match results and per-player scores |
| 2 | Question cache with category, difficulty, tags, and source metadata |
| 3 | Player profiles, XP, streaks, unlocks |
| 4 | Leaderboards and seasonal ranks |
| 5 | Custom packs, moderation logs, admin tools |

### Best Practical Architecture

For this project, a sensible evolution path is:

1. Keep live gameplay in PartyKit memory.
2. Add a database only for persistence and analytics.
3. Cache question sets ahead of match start.
4. Write finished match summaries asynchronously after the game ends.

### Good Storage Choices

| Need | Suggested storage |
|---|---|
| Match history, accounts, leaderboards | Postgres |
| Fast cache for question batches / daily challenge payloads | Redis or edge KV |
| Analytics events | Postgres first, warehouse later if needed |
| User-generated packs / admin CMS | Postgres |

### Why Question Storage Can Help

Storing questions locally is useful if you want:

- Faster match startup
- Reduced dependency on OpenTDB uptime and rate limits
- Better content quality control
- Category and difficulty balancing
- Duplicate detection
- Editorial playlists and events

If you stay fully dependent on a public external API, you will eventually hit product limits before you hit engineering limits.

---

## Competitive Ideas

These are the ideas most likely to make QuizBlitz feel distinct rather than just competent.

### Amazing Gameplay Features

- **Clutch Round**: final question worth double, but only if you are within a score threshold.
- **Answer Streaks**: consecutive correct answers build a multiplier or visual flame trail.
- **Confidence Wager**: after reading the question, players can lock in a low, medium, or high confidence bet for score risk/reward.
- **Chaos Modifiers**: one random round per game changes the rules, such as hidden answers, speed-only scoring, or team vote round.
- **Rival Callout**: the UI highlights who you just passed or who is about to overtake you.
- **Photo Finish**: reveal the top three answer times after each round for extra tension.
- **Boss Questions**: every few rounds, insert a harder question with bigger upside and a more dramatic reveal.
- **Last-Place Comeback Card**: trailing players get one strategic catch-up mechanic per game.

### Features That Make It More Social

- **Room reactions** using quick emoji bursts after reveals.
- **Rematch vote** directly on the results screen.
- **Host presets** like Family Night, Pub Quiz, Classroom, Hardcore Speed Run.
- **Team mode** with 2v2 or squad scoring.
- **Spectator mode** so eliminated or late players can still watch and react.
- **Shareable result cards** for social posting.

### Features That Build Retention

- **Daily challenge** with one globally shared question set.
- **Weekly theme events** such as movies, football, science, anime.
- **Player stats page** with accuracy, average answer time, strongest category, and win rate.
- **Seasonal rank** with soft resets.
- **Unlockable cosmetics** tied to streaks, wins, and event participation.

### Features That Make It Feel Premium

- **Announcer-style audio** and stronger reveal pacing.
- **More cinematic transitions** between rounds.
- **Adaptive music intensity** near the end of a timer.
- **Broadcast mode** for TV, classroom, or Twitch screen sharing.
- **Host dashboard** with pacing controls and room moderation.

### If You Want the Short Answer

To compete, QuizBlitz needs three things beyond its current core:

1. **Persistent progression** so players care about returning.
2. **Curated and reliable content** so question quality feels premium.
3. **Social drama** so each round creates tension, surprise, and bragging rights.

